import pandas as pd
import os
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def load_job_roles():
    """Loads the job roles dataset from the CSV file."""
    job_path = os.path.join("data", "job_roles.csv")
    if os.path.exists(job_path):
        return pd.read_csv(job_path)
    return pd.DataFrame(columns=["Job Role", "Required Skills"])

def calculate_match_scores(cleaned_resume_text):
    """Calculates TF-IDF cosine similarity scores between resume and job roles."""
    jobs_df = load_job_roles()
    
    if jobs_df.empty:
        return []

    # Combine resume text with job requirements for vectorization
    job_descriptions = jobs_df["Required Skills"].tolist()
    corpus = job_descriptions + [cleaned_resume_text]
    
    # Initialize TF-IDF Vectorizer
    vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = vectorizer.fit_transform(corpus)
    
    # The last vector in the matrix represents the resume
    resume_vector = tfidf_matrix[-1]
    # The preceding vectors represent the job descriptions
    job_vectors = tfidf_matrix[:-1]
    
    # Calculate cosine similarity between resume and each job role
    similarity_scores = cosine_similarity(resume_vector, job_vectors).flatten()
    
    # Add scores to the dataframe (convert to percentage)
    jobs_df["Match Score"] = [round(score * 100, 2) for score in similarity_scores]
    
    # Sort roles from highest to lowest score
    ranked_jobs = jobs_df.sort_values(by="Match Score", ascending=False).to_dict(orient="records")
    
    return ranked_jobs