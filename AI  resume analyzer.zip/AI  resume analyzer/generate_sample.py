from docx import Document
import os

# Ensure sample resumes directory exists
os.makedirs("sample resumes", exist_ok=True)

# Create a Word document
doc = Document()
doc.add_heading('Alex Smith - Aspiring ML Engineer', 0)
doc.add_paragraph('Email: alex.smith@email.com | Phone: +91 9876543210')

doc.add_heading('Professional Summary', level=1)
doc.add_paragraph('Motivated engineering student with strong skills in Python, data science, machine learning models, and backend development.')

doc.add_heading('Technical Skills', level=1)
doc.add_paragraph('Programming: Python, C++, Java')
doc.add_paragraph('Data Science & Databases: Pandas, NumPy, SQL, MySQL')
doc.add_paragraph('Machine Learning & Tools: scikit-learn, Machine Learning, Deep Learning, FastAPI, Docker, Excel, Power BI')

doc.add_heading('Projects', level=1)
doc.add_paragraph('AI Resume Analyzer System: Developed an NLP-based dashboard using Streamlit, TF-IDF, and cosine similarity to evaluate resume matches against job roles.')

# Save the file into the sample resumes folder
file_path = "sample resumes/sample_resume.docx"
doc.save(file_path)
print(f"Sample resume created successfully at: {file_path}")