import re

def clean_text(text):
    """Cleans and normalizes resume text while preserving critical technical symbols."""
    if not text:
        return ""
    
    # Convert to lowercase for uniform comparison
    text = text.lower()
    
    # Replace special formatting/newlines with spaces
    text = re.sub(r'[\r\n\t]+', ' ', text)
    
    # Remove unwanted special characters, but preserve symbols like +, #, . (for C++, C#, .NET)
    text = re.sub(r'[^a-z0-9\s\+\#\.]', ' ', text)
    
    # Remove extra continuous whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text