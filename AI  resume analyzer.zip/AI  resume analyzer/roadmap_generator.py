def analyze_skill_gaps(candidate_skills, required_skills_str):
    """Compares candidate skills with required skills for a target job role."""
    # Convert required skills string from CSV into a clean list
    if not required_skills_str:
        required_list = []
    else:
        required_list = [skill.strip().lower() for skill in required_skills_str.split(",")]
        
    # Extract just the skill names from candidate skills dictionary
    candidate_skill_names = [str(item["Skill"]).lower() for item in candidate_skills]
    
    # Identify matched and missing skills
    matched_skills = [skill for skill in required_list if skill in candidate_skill_names]
    missing_skills = [skill for skill in required_list if skill not in candidate_skill_names]
    
    return matched_skills, missing_skills

def generate_learning_roadmap(missing_skills):
    """Generates a structured weekly learning roadmap based on missing skills."""
    roadmap = []
    
    if not missing_skills:
        return ["Great job! You already possess all the required core skills for this role. Focus on building advanced projects!"]
    
    # Create a simple week-by-week plan based on missing skills
    for i, skill in enumerate(missing_skills[:4], start=1):
        roadmap.append(f"Week {i}: Learn fundamentals and hands-on implementation of **{skill.title()}**.")
        
    if len(missing_skills) > 4:
        roadmap.append(f"Week {len(roadmap)+1}: Build a capstone project integrating remaining skills: {', '.join(missing_skills[4:])}.")
        
    return roadmap