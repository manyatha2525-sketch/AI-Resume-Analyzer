import pandas as pd
import os

def load_skill_dictionary():
    """Loads the skill dictionary from the CSV file."""
    skill_dict_path = os.path.join("data", "skill_dictionary.csv")
    if os.path.exists(skill_dict_path):
        df = pd.read_csv(skill_dict_path)
        return df
    return pd.DataFrame(columns=["Skill", "Category"])

def extract_skills(cleaned_text):
    """Scans cleaned resume text for skills from the controlled dictionary."""
    skill_df = load_skill_dictionary()
    found_skills = []
    
    if skill_df.empty:
        return found_skills

    # Check each skill from the dictionary in the resume text
    for _, row in skill_df.iterrows():
        skill = str(row["Skill"]).strip()
        category = str(row["Category"]).strip()
        
        # Use word boundary or simple substring check depending on skill format
        # Lowercase skill for matching
        skill_lower = skill.lower()
        
        if skill_lower in cleaned_text:
            # Avoid duplicates and append as a dictionary/tuple
            found_skills.append({
                "Skill": skill,
                "Category": category
            })
            
    return found_skills