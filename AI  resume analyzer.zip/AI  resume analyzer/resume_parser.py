import os
from pypdf import PdfReader
from docx import Document

def extract_text_from_pdf(uploaded_file):
    """Extracts text from each page of an uploaded PDF file."""
    text = ""
    try:
        reader = PdfReader(uploaded_file)
        for page in reader.pages:
            extracted = page.extract_text()
            if extracted:
                text += extracted + "\n"
    except Exception as e:
        print(f"Error reading PDF: {e}")
    return text

def extract_text_from_docx(uploaded_file):
    """Extracts text from each paragraph of an uploaded DOCX file."""
    text = ""
    try:
        doc = Document(uploaded_file)
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
    except Exception as e:
        print(f"Error reading DOCX: {e}")
    return text

def parse_resume(uploaded_file):
    """Determines file type and routes to the correct text extractor."""
    file_extension = os.path.splitext(uploaded_file.name)[1].lower()
    
    if file_extension == ".pdf":
        return extract_text_from_pdf(uploaded_file)
    elif file_extension in [".docx", ".doc"]:
        return extract_text_from_docx(uploaded_file)
    else:
        return ""