import streamlit as st
import pandas as pd
import plotly.express as px
from resume_parser import parse_resume
from text_cleaner import clean_text
from skill_extractor import extract_skills
from job_matcher import calculate_match_scores, load_job_roles
from roadmap_generator import analyze_skill_gaps, generate_learning_roadmap

# Page Configuration
st.set_page_config(page_title="AI Resume Analyzer & Job Recommendation System", layout="wide")

st.title("📄 AI Resume Analyzer and Job Recommendation System")
st.markdown("Upload your resume to evaluate your match score, discover missing skills, and get a custom learning roadmap!")

# Sidebar for file upload
st.sidebar.header("Navigation & Settings")
uploaded_file = st.sidebar.file_uploader("Upload Resume (PDF or DOCX)", type=["pdf", "docx"])

if uploaded_file is not None:
    st.sidebar.success(f"Uploaded: {uploaded_file.name}")
    
    # Process Resume
    raw_text = parse_resume(uploaded_file)
    cleaned_text = clean_text(raw_text)
    
    # Extract Skills & Calculate Matches
    extracted_skills = extract_skills(cleaned_text)
    ranked_jobs = calculate_match_scores(cleaned_text)
    
    # Main Dashboard Tabs
    tab1, tab2, tab3 = st.tabs(["📊 Dashboard & Matching", "🛠️ Skills Breakdown", "🚀 Learning Roadmap"])
    
    with tab1:
        st.subheader("Target Job Role Recommendations")
        if ranked_jobs:
            jobs_df = pd.DataFrame(ranked_jobs)
            
            # Display Match Score Chart using Plotly
            fig = px.bar(
                jobs_df, 
                x="Job Role", 
                y="Match Score", 
                text="Match Score",
                color="Match Score",
                color_continuous_scale="blues",
                title="Resume Match Scores Across Job Roles"
            )
            fig.update_traces(texttemplate='%{text}%', textposition='outside')
            st.plotly_chart(fig, use_container_width=True)
            
            # Show recommendations table
            st.dataframe(jobs_df[["Job Role", "Match Score"]], use_container_width=True)
            
            top_role = ranked_jobs[0]["Job Role"]
            top_score = ranked_jobs[0]["Match Score"]
            st.info(f"🏆 **Top Recommended Role:** {top_role} with a match score of **{top_score}%**!")
        else:
            st.warning("No job roles found in the dataset.")
            
    with tab2:
        st.subheader("Extracted Resume Skills")
        if extracted_skills:
            skills_df = pd.DataFrame(extracted_skills)
            st.dataframe(skills_df, use_container_width=True)
            st.metric("Total Skills Detected", len(extracted_skills))
        else:
            st.warning("No matching skills found in the skill dictionary.")
            
    with tab3:
        st.subheader("Skill-Gap Analysis & Learning Roadmap")
        
        job_roles_df = load_job_roles()
        if not job_roles_df.empty:
            selected_role = st.selectbox("Select Target Role for Skill Gap Analysis", job_roles_df["Job Role"].tolist())
            
            selected_row = job_roles_df[job_roles_df["Job Role"] == selected_role].iloc[0]
            required_skills_str = selected_row["Required Skills"]
            
            matched, missing = analyze_skill_gaps(extracted_skills, required_skills_str)
            
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("### ✅ Matched Skills")
                if matched:
                    for s in matched:
                        st.markdown(f"- {s.title()}")
                else:
                    st.write("None matched.")
                    
            with col2:
                st.markdown("### ❌ Missing Skills")
                if missing:
                    for s in missing:
                        st.markdown(f"- {s.title()}")
                else:
                    st.write("None! You have all required skills.")
                    
            st.markdown("---")
            st.subheader("📌 Suggested Weekly Learning Roadmap")
            roadmap = generate_learning_roadmap(missing)
            for step in roadmap:
                st.markdown(f"- {step}")
        else:
            st.warning("Job roles dataset is empty.")
else:
    st.info("👈 Please upload a PDF or DOCX resume using the sidebar to begin analysis.")